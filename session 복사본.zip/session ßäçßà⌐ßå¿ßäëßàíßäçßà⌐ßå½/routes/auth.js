var express = require('express');
var router = express.Router();
var path = reqwuire('path');
var fs = require('fs');
var sanitizeHtml = require('sanitize-html');
var template = require('../lib/template./js');

router.get('/login', function(request, response) {
    var title = "WEB - login";
    var list = template.list(request.list);
    var html = template.HTML(title, list, `
    <form action="/topic/create_process" method="post">
    <p><input type="text" name="title" placeholder="title"></p>
    <p>
        <textarea name="description" placeholder="description"></textarea>
    </p>
    <p>
        <input type="submit">
    </p>
    </form>
    `, '');
    response.send(html);
});

module.exports = router;

